
var _GameInit = function(){
	window.main = this;
	this.alpha = 1;

	this.player = _Player.init(this.app);
	this.asteroid = _Asteroid.init(this.app);
	this.otherplayer = [];
	this.otherplayer.push(this.player);


	//this.npc1 = Object.create(_Player).init(this.app);
	//this.npc1.position = {x:25,y:26};

	//this.otherplayer.push(this.npc1);
	//this.otherplayer.push(Object.create(_Player).init(this.app));
	this.title = _TitleMoon.init(this.app);
	this.ground = _GroundMoon.init(this.app);
	this.maps = {};
	this.maps.x = 0;
	this.maps.y = 0;
	this.off = new Math.Vector(0,0);
	this.spritelist = [];
	this.spritelist['stars0'] = this.graphics.load('./images/moon-stars0','./images/moon-stars0');
	this.spritelist['stars1'] = this.graphics.load('./images/moon-stars1','./images/moon-stars1');

	this.gameobjectlist = [];

	this.gameObject = function(type,position,image){

		var object = new type(position.x,position.y,image);
		this.gameobjectlist.push(object);

	}

	for(var i = 0; i<=0; i++)
		this.gameObject(_Melon,new Math.Vector(25+35*i,this.app.height-75),this.player.spritelist['moon-character']);


		var img = this.player.spritelist['moon-character'];
		var self = this;
		setInterval(function(){

			var val = new Math.Vector(self.maps.x+25+Math.random()*self.app.width,self.app.height-75);
			self.gameObject(_Melon,val,img);

		},1050);

};

var _GameDraw = function() {

				var img = this.spritelist['stars0'];
				this.visuals.image(img,-this.maps.x*0.02,0, this.alpha);
				var img = this.spritelist['stars1'];
				this.visuals.image(img,-this.maps.x*0.001,0, this.alpha);


			this.ground.draw(this.player);
			//this.asteroid.draw();
			//this.player.map = this.map;
			//this.player.draw();


			this.off.x += this.player.vel.x;
			this.maps.x += this.player.vel.x;


			//						if (this.off.x>200){

			//	this.off.x -=  (this.off.x-200)/1.5;
				//this.maps.x -=  (this.off.x-200)/10;
			//	this.maps.x *=0.9;
			//						}


			if (this.off.x>50){

				//this.maps.x*=0.99;
				//this.off.x*=0.99;
				this.maps.x+=this.off.x/100;
				this.off.x-=this.off.x/100;
				//this.off.x*=0.99;
				//this.maps.x*=1.01;

			}
			if (this.off.x<this.maps.x) {

				//this.off.x -= (this.off.x-this.maps.x)*0.01;

			}

			if (this.off.x<-50){

				//this.maps.x+=this.off.x/100;
				//this.off.x-=this.off.x/100;
				//this.off.x*=0.99;
				//this.maps.x*=1.01;

			}
//						this.maps.x += this.player.vel.x;
		//	this.player.vel.x *= 0.9;
			//this.off.x = 250;

			//this.off.x -=this.player.vel.x/5;
			//this.off.x*=0.8;
			//this.map.x += this.player.vel.x;
			//this.maps.x += this.otherplayer[0].vel.x;

			/*
			if (this.maps.x<0)
			this.maps.x = 0;

			if (this.maps.x>450)
			this.maps.x = 450;
*/


			this.ground.offx = -this.maps.x;
			this.player.off.x = -this.off.x;

			for(var i = 0; i<=this.gameobjectlist.length-1; i++) {

				var obj = this.gameobjectlist[i];
				obj.off.x = this.off.x;
				var MAPS = new Math.Vector(this.maps.x,this.maps.y);
				//MAPS.x-=this.off.x;
				MAPS.x = this.maps.x;
				obj.draw(this.visuals,MAPS);
				switch(obj.type){

					case 100:
						if (obj._image_index<=obj.image_count)
							obj._image_index+=obj.image_speed,obj.image_index = Math.floor(obj._image_index);
							else obj.image_index = 5,obj._image_index = 0;
					break;


				}

			}

			for(var i = 0; i<=this.otherplayer.length-1; i++) {
				var player = this.otherplayer[i];
				if (i==0) {

					player.maps = this.maps;
					player.draw();

				} else {
					//player.position.x = window.position.x;
					//player.position.y = window.position.y;
					//player.vel.x = window.vel.x;
					//player.vel.y = window.vel.y;
					player.maps = this.maps;
					player.draw(window.position,window.vel);
					//this.visuals.text(Math.round(window.position.x),125,125,"#FFFFFF");
				}
			}
			this.visuals.text("OFFX"+Math.round(this.off.x),125,125,"#FFFFFF");
			this.visuals.text("MAPSX"+Math.round(this.maps.x),125,145,"#FFFFFF");
				//this.title.draw();

			};
			var _App_Main = {

				init:_GameInit,

				update:function(){
								for(var i = 0; i<=this.gameobjectlist.length-1; i++) {
									var obj = this.gameobjectlist[i];
									obj.updateHit(this.player);
									obj.update(this.player);
								}

				},

				draw:_GameDraw

			};

var _App = ((SpiceJS.create()).OnLoad = function (self) {

	var width = _RESOLUTION_WIDTH;
	var height = _RESOLUTION_HEIGHT;

	self.main = _App_Main;

	self.start(width, height);

	window.Application = this;

});
