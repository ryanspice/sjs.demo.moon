
var _THINGY_COUNT = 0;

var _Thingy = function(){

	var Thingy = function forgeimage(temp){

		temp.hit = false;
		temp.updateHit = function(other){

			this.app = SpiceJS.controller.list(0);
			var a = -this.app.client.setWidth/2 + this.x-main.maps.x-main.off.x;
			if (a>-30)
			if (a<30) {

					this.hit = true;

			}

			return;
			//var position = new Math.Vector(this.x-this.positon.x,0);
			var other_position = new Math.Vector(other.position.x,other.position.y);
			var offset = (new Math.Vector()).Difference(this.position, other_position)



			if ((offset.x<25)&&
				(offset.y<40)&&
				(offset.y<40)&&
				(offset.x>-25))
				this.hit = true;

		};

		temp.delete = false;

	};

	return (function(props){

		var _temp =  new Math.Vector(props[0],props[1]);

		_temp.type = 0;

		_temp.image = props[2];

		_temp.id = _THINGY_COUNT;

		_THINGY_COUNT++;

		Thingy(_temp);

		return _temp;

	})(arguments);

};
