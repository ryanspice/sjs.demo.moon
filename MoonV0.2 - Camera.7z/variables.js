/* Constant Variables */

var _GRAVITY = 1.7028871391075;
var _RESOLUTION_WIDTH = 720;
var _RESOLUTION_HEIGHT  = 540;

/* Player Variables */

var _PLAYER_SPEED = 1;
var _PLAYER_IMAGESPEED_ = 0.25;
var _PLAYER_IMAGE_COUNT = 10; //OVERRIDE to number of frames in animation
var _PLAYER_JUMP_VELOCITY; // OVERRIDE with a number

/* Object Variables */

var _MELON_IMAGESPEED  = 0.01;


_PLAYER_IMAGESPEED_ = 0.2;
_PLAYER_IMAGE_COUNT = 10; //OVERRIDE to number of frames in animation
_PLAYER_JUMP_VELOCITY; // OVERRIDE with a number
_MELON_IMAGESPEED  = 0.2;
