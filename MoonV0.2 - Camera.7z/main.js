
var _GameInit = function(){
	window.main = this;
	this.alpha = 1;

	this.player = _Player.init(this.app);
	this.asteroid = _Asteroid.init(this.app);
	this.otherplayer = [];
	this.otherplayer.push(this.player);


	//this.npc1 = Object.create(_Player).init(this.app);
	//this.npc1.position = {x:25,y:26};

	//this.otherplayer.push(this.npc1);
	//this.otherplayer.push(Object.create(_Player).init(this.app));
	this.title = _TitleMoon.init(this.app);
	this.ground = _GroundMoon.init(this.app);
	this.maps = {};
	this.maps.x = 0;
	this.maps.y = 0;
	this.off = new Math.Vector(0,0);
	this.spritelist = [];
	this.spritelist['stars0'] = this.graphics.load('./images/moon-stars0','./images/moon-stars0');
	this.spritelist['stars1'] = this.graphics.load('./images/moon-stars1','./images/moon-stars1');

	this.gameobjectlist = [];

	this.gameObject = function(type,position,image){

		var object = new type(position.x,position.y,image);
		this.gameobjectlist.push(object);

		return this.gameobjectlist.length;
	}

	for(var i = 0; i<=0; i++)
		this.gameObject(_Melon,new Math.Vector(25+35*i,this.app.height-155),this.player.spritelist['moon-character']);


		var img = this.player.spritelist['moon-character'];
		var self = this;


		setInterval(function(){

			var val = new Math.Vector(self.maps.x+25+Math.random()*self.app.width,self.app.height-75);
			self.gameObject(_Melon,val,img);

		},1050);

		var val = new Math.Vector(self.maps.x+25+Math.random()*self.app.width,self.app.height-75);



	var level = [];
	var newlevelpiece = function(position,breakable){

		var tiletemp = 	{
			position:position,
			breakable:breakable||false
		}

		level.push(tiletemp);

	}

	for(var i = 0; i<=64; i++){

			newlevelpiece(new Math.Vector(-550+i*32.5,+this.app.client.height-25))

	}

	for(var i = 0; i<=2; i++){

			newlevelpiece(new Math.Vector(100+i*32.5,48+this.app.client.height-225))
	}
	for(var i = 0; i<=2; i++){

			newlevelpiece(new Math.Vector(800+i*32.5,164-i*16+this.app.client.height-204))
			i+3;
			newlevelpiece(new Math.Vector(898+i*32.5,148+i*16+this.app.client.height-204))
			i-3;
	}


		for(var i = 0; i<=2; i++){

				newlevelpiece(new Math.Vector(1100+i*32.5,148+this.app.client.height-225))
				newlevelpiece(new Math.Vector(1100+i*32.5,116+this.app.client.height-225))
		}


		for(var i = 0; i<=2; i++){

				newlevelpiece(new Math.Vector(1200+i*32.5,172+this.app.client.height-204),true)
				newlevelpiece(new Math.Vector(1200+i*32.5,140+this.app.client.height-204),true)
		}


	for(var i = 0; i<=level.length-1; i++){

		var tile = level[i];

		var id = this.gameObject(_Solid,new Math.vector(tile.position.x,tile.position.y),img);

		this.gameobjectlist[id-1].breakable = tile.breakable;

	}

		//		this.gameObject(_Solid,new Math.Vector(190,190),new Image());
};

var _GameDraw = function() {

				var img = this.spritelist['stars0'];
				this.visuals.image(img,-this.maps.x*0.02,0, this.alpha);
				var img = this.spritelist['stars1'];
				this.visuals.image(img,-this.maps.x*0.001,0, this.alpha);


			this.ground.draw(this.player);
			//this.asteroid.draw();
			//this.player.map = this.map;
			//this.player.draw();


			this.off.x += this.player.vel.x;
			this.maps.x += this.player.vel.x;


			//						if (this.off.x>200){

			//	this.off.x -=  (this.off.x-200)/1.5;
				//this.maps.x -=  (this.off.x-200)/10;
			//	this.maps.x *=0.9;
			//						}


			if (this.off.x>50){

				//this.maps.x*=0.99;
				//this.off.x*=0.99;
				this.maps.x+=this.off.x/100;
				this.off.x-=this.off.x/100;
				//this.off.x*=0.99;
				//this.maps.x*=1.01;

			}
			if (this.off.x<this.maps.x) {

				//this.off.x -= (this.off.x-this.maps.x)*0.01;

			}

			if (this.off.x<-50){

				this.maps.x+=this.off.x/100;
				this.off.x-=this.off.x/100;
				//this.off.x*=0.99;
				//this.maps.x*=1.01;

			}
//						this.maps.x += this.player.vel.x;
		//	this.player.vel.x *= 0.9;
			//this.off.x = 250;

			//this.off.x -=this.player.vel.x/5;
			//this.off.x*=0.8;
			//this.map.x += this.player.vel.x;
			//this.maps.x += this.otherplayer[0].vel.x;

			/*
			if (this.maps.x<0)
			this.maps.x = 0;

			if (this.maps.x>450)
			this.maps.x = 450;
*/


			this.ground.offx = -this.maps.x;
			this.player.off.x = -this.off.x;
			for(var i = 0; i<=this.gameobjectlist.length-1; i++) {

				var obj = this.gameobjectlist[i];
				obj.off.x = this.off.x;
				var MAPS = new Math.Vector(this.maps.x,this.maps.y);
				//MAPS.x-=this.off.x;
				MAPS.x = this.maps.x;
				obj.draw(this.visuals,MAPS);
				switch(obj.type){

					case 100:
						if (obj._image_index<=obj.image_count)
							obj._image_index+=obj.image_speed,obj.image_index = Math.floor(obj._image_index);
							else obj.image_index = 5,obj._image_index = 0;
					break;


				}

			}

			for(var i = 0; i<=this.otherplayer.length-1; i++) {
				var player = this.otherplayer[i];
				if (i==0) {

					player.maps = this.maps;
					player.draw();

				} else {
					//player.position.x = window.position.x;
					//player.position.y = window.position.y;
					//player.vel.x = window.vel.x;
					//player.vel.y = window.vel.y;
					player.maps = this.maps;
					player.draw(window.position,window.vel);
					//this.visuals.text(Math.round(window.position.x),125,125,"#FFFFFF");
				}
			}
			this.visuals.text("OFFX"+Math.round(this.off.x),125,125,"#FFFFFF");
			this.visuals.text("MAPSX"+Math.round(this.maps.x),125,145,"#FFFFFF");
			this.visuals.text("SCALE"+Math.round(this.app.client.scale*100)/100,125,165,"#FFFFFF");
			this.visuals.text("PLAYERVELY"+Math.round(_Player.vel.y*100)/100,125,185,"#FFFFFF");
				//this.title.draw();

			};
			var _App_Main = {

				init:_GameInit,

				update:function(){


					for(var i = 0; i<=this.gameobjectlist.length-1; i++) {
						var obj = this.gameobjectlist[i];
						obj.updateHit(this.player);
						obj.update(this.player);
					}

				},

				draw:_GameDraw

			};

var _App = ((SpiceJS.create()).OnLoad = function (self) {

	var width = _RESOLUTION_WIDTH;
	var height = _RESOLUTION_HEIGHT;

	self.main = _App_Main;

	self.start(width, height);

	window.Application = this;

});
